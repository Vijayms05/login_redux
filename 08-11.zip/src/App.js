import React from 'react'
import RecordView from './RecordView'
// import Home from './component/home/Home'
import Routes from './routes/Routes'

const App =()=>{
    return (
        <Routes />
    )
}
export default App