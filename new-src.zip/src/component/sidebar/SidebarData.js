

// import {TestIcon, ReportIcon, RupeeIcon, SettingIcon, ProfileIcon, MySubscriptions} from '../logo/index'
// export const SidebarData =[
//     {
//         title:"My Subscriptions",
//         icon: <MySubscriptions />,
//         path: "/mysubscription"

//     },
//     {
//         title:"Tests",
//         icon: <TestIcon />,
//         path: "/tests"
//     },
//     {
//         title:"Reports",
//         icon: <ReportIcon />,
//         path: "/reports"

//     },
//     {
//         title:"Billing",
//         icon: <RupeeIcon />,
//         path: "/billing"

//     },
//     {
//         title:"Settings",
//         icon: <SettingIcon />,
//         path: "/settings"

//     },
//     {
//         title:"Profile",
//         icon: <ProfileIcon />,
//         path: "/profile"

//     },
// ]