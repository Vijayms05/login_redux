
import { combineReducers } from 'redux';
import SignupState from './Signup'

const rootReducer = combineReducers({
    SignupState,
})
export default rootReducer;